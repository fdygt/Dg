# Contoh konfigurasi database tambahan
DATABASE_POOL_SIZE = 10
DATABASE_TIMEOUT = 30

# Konfigurasi rate limiting
RATE_LIMIT = "100/minute"
RATE_LIMIT_STRATEGY = "fixed-window"

# Konfigurasi terkait keamanan
JWT_SECRET_KEY = "your-jwt-secret-key"
TOKEN_EXPIRATION_SECONDS = 3600
PASSWORD_HASH_SCHEME = "bcrypt"
